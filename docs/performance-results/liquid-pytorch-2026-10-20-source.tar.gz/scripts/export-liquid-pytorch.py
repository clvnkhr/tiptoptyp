#!/usr/bin/env python3
"""Export and verify the pinned Liquid tagger for the Python-free native helper.

Developer setup (Apple Silicon, Python 3.12; no Python is shipped to users):
  python3.12 -m venv /private/tmp/liquid-pytorch-build
  /private/tmp/liquid-pytorch-build/bin/python -m pip install -r scripts/liquid-pytorch-requirements.txt
  /private/tmp/liquid-pytorch-build/bin/python scripts/liquid-grammar-worker.py --cache-dir /private/tmp/liquid-reference --install

Export, verify, then build both native helpers and prepare the compressed payload:
  /private/tmp/liquid-pytorch-build/bin/python scripts/export-liquid-pytorch.py --cache-dir /private/tmp/liquid-reference --output-dir /private/tmp/liquid-pytorch-raw --export
  /private/tmp/liquid-pytorch-build/bin/python scripts/export-liquid-pytorch.py --cache-dir /private/tmp/liquid-reference --output-dir /private/tmp/liquid-pytorch-raw --verify
  python3 scripts/build-liquid-pytorch.py --source /private/tmp/liquid-pytorch-raw --work-dir /private/tmp/liquid-pytorch-vendor
  cargo xtask prepare-liquid --source /private/tmp/liquid-pytorch-raw
  cargo xtask stage-liquid

Only the explicit reference install and native builder download artifacts. Export
and verification are offline. The on-disk TorchScript module is UNFROZEN: the
helper must load on CPU, cast to Float32, eval, then freeze in memory. Parameters
are stored as FP16 only when the FP32 round trip is bit-exact; all inference is
FP32. Build-only export/parity receipts go in the sibling OUTPUT-evidence folder,
not in the strictly validated raw payload. The model/tokenizer are shared by ARM LibTorch 2.14.1 (macOS 14+) and Intel
LibTorch 2.2.2 (macOS 12+). The optional reranker is not included.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.metadata
import importlib.util
import json
import math
from pathlib import Path
import shutil
import sys
import zipfile

HERE = Path(__file__).resolve().parent
LIMIT = 128
CANONICAL_FIXTURE_SHA256 = "3567a30d66d213ad47a3fbd7cbedad4974ea9b6e19037326da82ee5050159dc2"
REQUIRED_CASES = 268
REQUIRED_PASSES = 427
LICENSE_SHA256 = "4d28ca14dedc0b3d0fcc2b3339f0e79931faa33874f3d24f522183a8fc70068c"


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def load_reference(cache, threads):
    spec = importlib.util.spec_from_file_location("_liquid_pytorch_reference", HERE / "liquid-grammar-worker.py")
    worker = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = worker
    spec.loader.exec_module(worker)
    return worker, worker.load_adapter(cache, threads).adapter


def evidence_directory(output):
    # Keep build-only receipts outside the strict redistributable raw tree.
    directory = output.parent / (output.name + "-evidence")
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def tensor_digest(value):
    return hashlib.sha256(value.detach().contiguous().numpy().tobytes()).hexdigest()


def snapshot(model):
    return {kind: {name: tensor_digest(value) for name, value in values}
            for kind, values in [("parameters", model.named_parameters()),
                                 ("buffers", model.named_buffers())]}


def portable_clone(original):
    """Keep the reference object/classes unchanged, including its SDPA backend."""
    model = copy.deepcopy(original).float().eval()
    # Select eager BEFORE assigning safe dynamic classes: HF source inspection
    # cannot recognize the subclasses and otherwise silently leaves GQA active.
    model.encoder.set_attn_implementation("eager")
    if model.encoder.config._attn_implementation != "eager":
        raise RuntimeError("The pinned encoder did not select eager attention")
    safe_types = {}
    for child in model.modules():
        original_type = type(child)
        if any(not part.isidentifier() for part in original_type.__module__.split(".")):
            if original_type not in safe_types:
                safe_types[original_type] = type(original_type.__name__, (original_type,),
                                                 {"__module__": "liquid_native_portable"})
            child.__class__ = safe_types[original_type]
    return model


def compact_parameters(model):
    import torch
    compacted, retained = [], []
    for name, parameter in model.named_parameters():
        value = parameter.detach()
        if value.dtype == torch.float32:
            half = value.half()
            # Compare bits, not numerical equality (which loses signed zero).
            if torch.equal(value.view(torch.int32), half.float().view(torch.int32)):
                compacted.append({"name": name, "elements": value.numel(),
                                  "float32_sha256": tensor_digest(value)})
                parameter.data = half
                continue
        retained.append({"name": name, "dtype": str(value.dtype)})
    return {"compacted_parameters": compacted, "retained_parameters": retained,
            "saved_parameter_bytes": sum(row["elements"] * 2 for row in compacted),
            "parameter_fp16_roundtrip_bit_exact": True, "arithmetic": "float32",
            "lossy_quantization": False, "buffers_compacted": False}


def export(worker, reference, cache, output):
    import torch
    if (output / "liquid.pt").exists():
        raise ValueError("Export destination already contains a model; choose a fresh folder")
    output.mkdir(parents=True, exist_ok=True)
    before = snapshot(reference.model)
    attention = reference.model.encoder.config._attn_implementation
    model = portable_clone(reference.model)

    class Forward(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.model = model

        def forward(self, input_ids, attention_mask):
            result = self.model(input_ids, attention_mask)
            return (result["label_logits"].argmax(-1),
                    result["detect_logits"].softmax(-1)[..., 1])

    ids = torch.tensor([[1, *reference.tokenizer.encode("She go to school every day .",
                                                       add_special_tokens=False)]], dtype=torch.int64)
    with torch.inference_mode():
        traced = torch.jit.trace(Forward().eval(), (ids, torch.ones_like(ids)),
                                 strict=True, check_trace=False)
    operators = torch.jit.export_opnames(traced)
    if any("scaled_dot_product" in name for name in operators):
        raise RuntimeError("The graph still contains version-dependent SDPA/GQA")
    storage = compact_parameters(traced)
    expected_buffers = {name: tensor_digest(value) for name, value in traced.named_buffers()}
    temporary = output / ".liquid-building.pt"
    traced.save(str(temporary))
    target = output / "liquid.pt"
    temporary.replace(target)
    del traced, model
    # Prove serialization plus the native load-time cast retain every bit.
    loaded = torch.jit.load(str(target), map_location="cpu").eval().to(torch.float32)
    after = snapshot(loaded)
    if {name.removeprefix("model."): value for name, value in after["parameters"].items()} != before["parameters"]:
        raise RuntimeError("Reloaded parameter bits differ from the pinned reference")
    if after["buffers"] != expected_buffers:
        raise RuntimeError("Serialization changed the original FP32 buffers")
    if snapshot(reference.model) != before or reference.model.encoder.config._attn_implementation != attention:
        raise RuntimeError("Export changed the reference model")
    tokenizer = worker.artifact_path(cache, worker.ARTIFACTS[4])
    shutil.copyfile(tokenizer, output / "tokenizer.json")
    license_file = HERE.parent / "assets/liquid/LFM-Open-License.txt"
    if digest(license_file) != LICENSE_SHA256:
        raise ValueError("The pinned upstream model license is missing or changed")
    shutil.copyfile(license_file, output / "LICENSE.txt")
    with zipfile.ZipFile(target) as archive:
        archive_versions = {name.rsplit("/", 1)[-1]: archive.read(name).decode().strip()
                            for name in archive.namelist()
                            if name.endswith(("/version", "/byteorder"))}
    info = {"format": 2, "source": "https://huggingface.co/" + worker.MODEL_REPO,
            "revision": worker.MODEL_REVISION, "encoder_revision": worker.ENCODER_REVISION,
            "model_sha256": digest(target), "tokenizer_sha256": digest(output / "tokenizer.json"),
            "model_bytes": target.stat().st_size, "torchscript_archive": archive_versions,
            "change": "Portable eager-attention TorchScript; exact FP16 parameter storage, restored FP32 CPU inference; no retraining, quantization or reranker.",
            "inputs": {"input_ids": "int64[1,sequence]", "attention_mask": "int64[1,sequence]"},
            "outputs": ["best_tags:int64[1,sequence]", "error_probs:float32[1,sequence]"],
            "minimum_sequence": 1, "maximum_sequence": LIMIT, "trace_sequence": ids.shape[1],
            "required_load": "CPU load; to(Float32); eval; freeze in memory",
            "reference_unchanged": True, "buffers_unchanged": True, "storage": storage,
            "operators": operators, "export_script_sha256": digest(__file__),
            "versions": {name: importlib.metadata.version(name) for name in
                         ["torch", "transformers", "tokenizers", "sacremoses"]},
            "source_artifacts": [{"repo": r, "revision": v, "name": n, "bytes": b, "sha256": h}
                                 for r, v, n, b, h in worker.ARTIFACTS]}
    write_json(evidence_directory(output) / "export.json", info)
    return loaded


def apply_predictions(ids, tags, errors, vocab_size):
    if not (len(ids) == len(tags) == len(errors)):
        raise ValueError("Prediction lengths do not match input")
    if any(not math.isfinite(float(value)) or not 0 <= float(value) <= 1 for value in errors):
        raise ValueError("Prediction probability is invalid")
    pieces = []
    for index, (piece, raw_tag, error) in enumerate(zip(ids, tags, errors)):
        tag = int(raw_tag) if int(raw_tag) != 0 and float(error) >= 0.5 else 0
        if not 0 <= tag < 2 + 2 * vocab_size:
            raise ValueError("Prediction tag is outside the pinned edit vocabulary")
        if tag == 0:
            if index:
                pieces.append(piece)
        elif tag == 1:
            continue
        elif tag < 2 + vocab_size:
            pieces.append(tag - 2)
        else:
            if index:
                pieces.append(piece)
            pieces.append(tag - 2 - vocab_size)
    return pieces


def correct(reference, text, step):
    prepared = " ".join(reference._tokens(text))
    seen = {prepared}
    result = prepared
    for _ in range(3):
        ids = [1, *reference.tokenizer.encode(prepared, add_special_tokens=False)]
        if len(ids) > LIMIT:
            raise ValueError("Reference input exceeds the 128-token model limit")
        tags, errors = step(ids)
        result = reference.tokenizer.decode(
            apply_predictions(ids, tags, errors, reference.model.vocab_size),
            skip_special_tokens=True).strip()
        if result == prepared or result in seen:
            break
        seen.add(result)
        prepared = result
    return reference._untokenize(result, text)


def validate_receipt(output, receipt):
    if (receipt.get("matched", 0) != REQUIRED_CASES
            or receipt.get("compared_reference_steps", 0) != REQUIRED_PASSES
            or receipt.get("fixture_sha256") != CANONICAL_FIXTURE_SHA256
            or not all(receipt.get(key) is True for key in
                       ["parameter_fp16_roundtrip_bit_exact", "reference_unchanged", "buffers_unchanged"])
            or receipt.get("mismatches") != []
            or receipt.get("model_sha256") != digest(output / "liquid.pt")
            or receipt.get("tokenizer_sha256") != digest(output / "tokenizer.json")
            or not 0 <= receipt.get("max_error_probability_delta", 1) <= 1e-4
            or [x.get("sequence") for x in receipt.get("shape_boundaries", [])] != [1, 2, 8, 32, 127, 128]
            or not all(x["tags_match"] and 0 <= x["max_error_probability_delta"] <= 1e-4
                       for x in receipt["shape_boundaries"])):
        raise ValueError("Passing parity for the exact current model/tokenizer is required")


def verify(reference, loaded, output, fixture):
    import torch
    import numpy as np
    if digest(fixture) != CANONICAL_FIXTURE_SHA256:
        raise ValueError("The maintained canonical correction fixture changed; review and update its export pin")
    export_info = json.loads((evidence_directory(output) / "export.json").read_text())
    if export_info["model_sha256"] != digest(output / "liquid.pt") or export_info["tokenizer_sha256"] != digest(output / "tokenizer.json"):
        raise ValueError("The exported model/tokenizer changed before verification")
    cases = json.loads(fixture.read_text())["cases"]
    mismatches, maximum, count, matched = [], 0.0, 0, 0

    def native_step(ids):
        values = torch.tensor([ids], dtype=torch.int64)
        tags, probs = loaded(values, torch.ones_like(values))
        return tags[0].numpy(), probs[0].numpy()

    with torch.inference_mode():
        for case_index, case in enumerate(cases, 1):
            if case.get("status") == "input_too_long":
                continue
            valid = True
            for index, step in enumerate(case["reference_passes"]):
                values = torch.tensor([step["input_ids"]], dtype=torch.int64)
                original = reference.model(values, torch.ones_like(values))
                original_tags = original["label_logits"].argmax(-1)[0].numpy()
                original_probs = original["detect_logits"].softmax(-1)[0, :, 1].numpy()
                tags, probs = native_step(step["input_ids"])
                if not (np.isfinite(probs).all() and np.isfinite(original_probs).all()):
                    raise ValueError("Nonfinite model output prevents parity validation")
                delta = max(float(np.max(np.abs(probs - original_probs))),
                            float(np.max(np.abs(probs - np.asarray(step["error_probs"])))))
                maximum = max(maximum, delta)
                tags_match = list(tags) == step["best_tags"] == list(original_tags)
                actions_match = apply_predictions(step["input_ids"], tags, probs,
                                                  reference.model.vocab_size) == step["output_ids"]
                if not tags_match or not actions_match or delta > 1e-4:
                    mismatches.append({"id": case["id"], "pass": index, "kind": "raw prediction"})
                    valid = False
                count += 1
            if correct(reference, case["text"], native_step) != case["reference_corrected"]:
                mismatches.append({"id": case["id"], "kind": "complete correction"})
                valid = False
            matched += valid
            if case_index % 20 == 0:
                print(f"Verified {case_index}/{len(cases)} canonical inputs", flush=True)
        shapes = []
        for length in [1, 2, 8, 32, 127, 128]:
            ids = torch.ones((1, length), dtype=torch.int64)
            original = reference.model(ids, ids)
            tags, probs = native_step([1] * length)
            shapes.append({"sequence": length,
                           "tags_match": list(tags) == original["label_logits"].argmax(-1)[0].tolist(),
                           "max_error_probability_delta": float(np.max(np.abs(probs - original["detect_logits"].softmax(-1)[0, :, 1].numpy())))})
    receipt = {"format": 2, "model_sha256": digest(output / "liquid.pt"),
               "tokenizer_sha256": digest(output / "tokenizer.json"),
               "fixture_sha256": digest(fixture), "matched": matched, "mismatches": mismatches,
               "parameter_fp16_roundtrip_bit_exact": export_info["storage"]["parameter_fp16_roundtrip_bit_exact"],
               "reference_unchanged": export_info["reference_unchanged"],
               "buffers_unchanged": export_info["buffers_unchanged"],
               "compared_reference_steps": count, "max_error_probability_delta": maximum,
               "shape_boundaries": shapes, "scope": "original PyTorch SDPA, native TorchScript eager, frozen research token/tag/correction goldens"}
    write_json(evidence_directory(output) / "parity.json", receipt)
    validate_receipt(output, receipt)
    provenance = json.loads((evidence_directory(output) / "export.json").read_text())
    provenance["parity"] = receipt
    provenance["runtimes"] = []
    write_json(output / "PROVENANCE.json", provenance)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--cache-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--threads", type=int, choices=range(1, 9), default=4)
    parser.add_argument("--export", action="store_true")
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    if not (args.export or args.verify):
        parser.error("choose --export and/or --verify")
    worker, reference = load_reference(args.cache_dir, args.threads)
    loaded = export(worker, reference, args.cache_dir, args.output_dir) if args.export else None
    if args.verify:
        if loaded is None:
            import torch
            loaded = torch.jit.load(str(args.output_dir / "liquid.pt"), map_location="cpu").eval().to(torch.float32)
        result = verify(reference, loaded, args.output_dir, HERE.parent / "assets/liquid/correction-cases.json")
        print(f"Parity: {result['matched']} corrections, {result['compared_reference_steps']} raw passes; {len(result['mismatches'])} mismatches")


if __name__ == "__main__":
    main()
