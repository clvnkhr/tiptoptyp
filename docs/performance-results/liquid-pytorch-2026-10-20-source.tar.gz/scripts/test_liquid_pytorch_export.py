"""Native export/build contract checks; no model downloads or inference corpus."""
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
from unittest.mock import patch

HERE = Path(__file__).resolve().parent


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, HERE / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


exporter = load("liquid_pytorch_export", "export-liquid-pytorch.py")
builder = load("liquid_pytorch_builder", "build-liquid-pytorch.py")
try:
    import torch
except ImportError:
    torch = None


class ExportContracts(unittest.TestCase):
    def test_canonical_fixture_pin_covers_distinct_inputs_and_all_refinement_passes(self):
        path = HERE.parent / "assets/liquid/correction-cases.json"
        self.assertEqual(exporter.digest(path), exporter.CANONICAL_FIXTURE_SHA256)
        self.assertEqual(builder.CANONICAL_FIXTURE_SHA256, exporter.CANONICAL_FIXTURE_SHA256)
        cases = json.loads(path.read_text())["cases"]
        self.assertEqual(len(cases), exporter.REQUIRED_CASES)
        self.assertEqual(len(set(case["text"] for case in cases)), exporter.REQUIRED_CASES)
        self.assertEqual(sum(len(case["reference_passes"]) for case in cases), exporter.REQUIRED_PASSES)

    def test_edit_vocabulary_boundaries_and_probability_gate(self):
        self.assertEqual(exporter.apply_predictions([1, 30, 40], [109, 2, 201], [1, 1, 1], 100),
                         [7, 0, 40, 99])
        self.assertEqual(exporter.apply_predictions([1, 30, 40], [0, 1, 100], [0, .4999, .4999], 100),
                         [30, 40])
        self.assertEqual(exporter.apply_predictions([1, 30, 40], [0, 1, 100], [0, .5, .5], 100), [98])
        with self.assertRaisesRegex(ValueError, "lengths"):
            exporter.apply_predictions([1, 30], [0], [0], 100)
        with self.assertRaisesRegex(ValueError, "vocabulary"):
            exporter.apply_predictions([1], [202], [1], 100)
        with self.assertRaisesRegex(ValueError, "probability"):
            exporter.apply_predictions([1], [0], [float("nan")], 100)

    def test_changed_model_or_missing_shape_proof_cannot_reuse_passing_parity(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "liquid.pt").write_bytes(b"model")
            (root / "tokenizer.json").write_bytes(b"tokenizer")
            receipt = {"matched": 268, "compared_reference_steps": 427, "mismatches": [], "max_error_probability_delta": 0,
                       "fixture_sha256": exporter.CANONICAL_FIXTURE_SHA256,
                       "parameter_fp16_roundtrip_bit_exact": True, "reference_unchanged": True, "buffers_unchanged": True,
                       "model_sha256": exporter.digest(root / "liquid.pt"),
                       "tokenizer_sha256": exporter.digest(root / "tokenizer.json"),
                       "shape_boundaries": [{"sequence": n, "tags_match": True,
                                              "max_error_probability_delta": 0}
                                             for n in [1, 2, 8, 32, 127, 128]]}
            exporter.validate_receipt(root, receipt)
            receipt["shape_boundaries"].pop()
            with self.assertRaisesRegex(ValueError, "exact current"):
                exporter.validate_receipt(root, receipt)
            receipt["shape_boundaries"].append({"sequence": 128, "tags_match": True,
                                               "max_error_probability_delta": 0})
            (root / "liquid.pt").write_bytes(b"changed model")
            with self.assertRaisesRegex(ValueError, "exact current"):
                exporter.validate_receipt(root, receipt)

    def test_export_receipts_stay_outside_the_strict_raw_tree(self):
        with tempfile.TemporaryDirectory() as directory:
            raw = Path(directory) / "raw"
            raw.mkdir()
            evidence = exporter.evidence_directory(raw)
            self.assertEqual(evidence, raw.parent / "raw-evidence")
            self.assertEqual(list(raw.iterdir()), [])

    @unittest.skipIf(torch is None, "optional pinned export environment is not installed")
    def test_portable_clone_selects_eager_before_safe_names_without_mutating_reference(self):
        import types
        class Encoder(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.config = types.SimpleNamespace(_attn_implementation="sdpa")
            def set_attn_implementation(self, value):
                self.selected_while_remote = any(not part.isidentifier() for part in type(self).__module__.split("."))
                self.config._attn_implementation = value
        Remote = type("RemoteEncoder", (Encoder,), {"__module__": "dynamic.123abc.model"})
        model = torch.nn.Module()
        model.encoder = Remote()
        cloned = exporter.portable_clone(model)
        self.assertTrue(cloned.encoder.selected_while_remote)
        self.assertEqual(cloned.encoder.config._attn_implementation, "eager")
        self.assertEqual(type(cloned.encoder).__module__, "liquid_native_portable")
        self.assertEqual(type(model.encoder).__module__, "dynamic.123abc.model")
        self.assertEqual(model.encoder.config._attn_implementation, "sdpa")

    @unittest.skipIf(torch is None, "optional pinned export environment is not installed")
    def test_half_storage_requires_bit_exact_whole_parameter_round_trip(self):
        original = torch.nn.Linear(2, 1)
        with torch.no_grad():
            original.weight.copy_(torch.tensor([[1.0, 1.0001]]))
            original.bias.copy_(torch.tensor([-0.0]))
        original.register_buffer("precise_buffer", torch.tensor([1.0001]))
        before = exporter.snapshot(original)
        import copy
        cloned = copy.deepcopy(original)
        report = exporter.compact_parameters(cloned)
        self.assertEqual([row["name"] for row in report["compacted_parameters"]], ["bias"])
        self.assertEqual(cloned.weight.dtype, torch.float32)
        self.assertEqual(cloned.precise_buffer.dtype, torch.float32)
        self.assertEqual(cloned.bias.dtype, torch.float16)
        cloned.to(torch.float32)
        self.assertEqual(exporter.snapshot(cloned), before)
        self.assertEqual(exporter.snapshot(original), before)
        self.assertEqual(cloned.bias.view(torch.int32).tolist(), [-2147483648])


class BuildContracts(unittest.TestCase):
    def test_download_stops_after_pinned_size_plus_one_byte(self):
        class Source(io.BytesIO):
            consumed = 0
            def read(self, count=-1):
                result = super().read(count)
                self.consumed += len(result)
                return result
        source = Source(b"x" * (1024 * 1024))
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with patch.object(builder.urllib.request, "urlopen", return_value=source):
                with self.assertRaisesRegex(ValueError, "checksum mismatch"):
                    builder.download(("https://example.invalid/file.zip", 3, "0" * 64), root, False)
            self.assertEqual(source.consumed, 4)
            self.assertEqual(list(root.iterdir()), [])

    def test_normalization_removes_openmp_ids_and_vendor_rpaths_without_undeclared_dependencies(self):
        names = ["liquid-pytorch", "libc10.dylib", "libomp.dylib"]
        self.assertEqual(builder.normalization_plan("libomp.dylib", names,
            "/opt/llvm-openmp/lib/libomp.dylib",
            ["/opt/llvm-openmp/lib/libomp.dylib", "/usr/lib/libSystem.B.dylib"],
            ["/nfs/vendor/build"]),
            [("-id", "@rpath/libomp.dylib"), ("-delete_rpath", "/nfs/vendor/build")])
        self.assertEqual(builder.normalization_plan("liquid-pytorch", names, None,
            ["@rpath/libc10.dylib", "/developer/lib/libomp.dylib"], ["/developer/lib"]),
            [("-change", "/developer/lib/libomp.dylib", "@loader_path/libomp.dylib"),
             ("-delete_rpath", "/developer/lib"), ("-add_rpath", "@loader_path")])
        with self.assertRaisesRegex(ValueError, "outside"):
            builder.normalization_plan("liquid-pytorch", names, None, ["@rpath/unbundled.dylib"], [])
        self.assertEqual(builder.native_rpaths("cmd LC_RPATH\n cmdsize 32\n path @loader_path (offset 12)\n"), ["@loader_path"])
        self.assertEqual(builder.minimum_os("cmd LC_BUILD_VERSION\n platform 1\n minos 14.0\n sdk 14.5\n"), "14.0")

    def test_smoke_requires_correct_target_and_loaded_model_prediction(self):
        ready = {"ready": True, "protocol": 1, "target": "aarch64-apple-darwin", "threads": 4}
        prediction = {"id": 1, "ok": True, "best_tags": [0] * 6, "error_probs": [.1] * 6}
        builder.validate_smoke(ready["target"], json.dumps(ready) + "\n" + json.dumps(prediction))
        with self.assertRaisesRegex(ValueError, "smoke"):
            builder.validate_smoke("x86_64-apple-darwin", json.dumps(ready) + "\n" + json.dumps(prediction))
        prediction["error_probs"][0] = float("nan")
        with self.assertRaisesRegex(ValueError, "smoke"):
            builder.validate_smoke(ready["target"], json.dumps(ready) + "\n" + json.dumps(prediction))

    def test_offline_download_rejects_corrupt_cache_without_network(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            pin = ("https://example.invalid/artifact.zip", 3, "0" * 64)
            with self.assertRaisesRegex(ValueError, "Missing pinned"):
                builder.download(pin, root, True)
            (root / "artifact.zip").write_bytes(b"bad")
            with self.assertRaisesRegex(ValueError, "checksum mismatch"):
                builder.download(pin, root, True)

    def test_archive_traversal_and_symlinks_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for index, name in enumerate(["../outside", "/absolute", "libtorch/lib/linked"]):
                archive = root / f"unsafe-{index}.zip"
                with zipfile.ZipFile(archive, "w") as output:
                    info = zipfile.ZipInfo(name)
                    if index == 2:
                        info.external_attr = 0o120777 << 16
                    output.writestr(info, "content")
                with self.assertRaisesRegex(ValueError, "Unsafe"):
                    builder.extract_vendor(archive, root / f"vendor-{index}")
            self.assertFalse((root / "outside").exists())

    def test_notices_include_all_wheel_and_openmp_sections_and_preserve_cp1252(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            wheel, extra = root / "torch.whl", root / "openmp.whl"
            with zipfile.ZipFile(wheel, "w") as output:
                output.writestr("torch.dist-info/LICENSE", "PyTorch license")
                output.writestr("torch.dist-info/NOTICE", "Third-party notice")
                output.writestr("torch/private.py", "must not include code")
            with zipfile.ZipFile(extra, "w") as output:
                output.writestr("intel.data/data/licensing/openmp/third-party-programs.txt", b"Intel \x93notice\x94")
                output.writestr("intel.dist-info/LICENSE.txt", "Intel license")
            destination = root / "notices.txt"
            builder.create_notices("x86_64-apple-darwin", builder.DISTRIBUTIONS["x86_64-apple-darwin"], wheel, extra, destination)
            text = destination.read_text()
            for expected in ["PyTorch license", "Third-party notice", "Intel license", "Intel “notice”"]:
                self.assertIn(expected, text)
            self.assertNotIn("must not include code", text)

    def test_native_runtime_closure_and_deployment_targets_are_explicit(self):
        for target, minimum, openmp in [("aarch64-apple-darwin", [14, 0], "libomp.dylib"),
                                        ("x86_64-apple-darwin", [12, 0], "libiomp5.dylib")]:
            settings = builder.DISTRIBUTIONS[target]
            self.assertEqual(settings["minimum_macos"], minimum)
            self.assertEqual(builder.runtime_names(settings),
                             ["liquid-pytorch", "libc10.dylib", "libtorch.dylib", "libtorch_cpu.dylib", openmp])
            for key in ["archive", "notices_wheel"]:
                url, size, sha = settings[key]
                self.assertTrue(url.startswith("https://"))
                self.assertGreater(size, 0)
                self.assertRegex(sha, r"^[0-9a-f]{64}$")


if __name__ == "__main__":
    unittest.main()
