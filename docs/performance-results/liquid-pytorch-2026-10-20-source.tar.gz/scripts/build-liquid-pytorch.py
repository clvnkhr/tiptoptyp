#!/usr/bin/env python3
"""Build the pinned Python-free Liquid helpers for both macOS architectures.

Run after export-liquid-pytorch.py --export and --verify:
  python3 scripts/build-liquid-pytorch.py --source /private/tmp/liquid-pytorch-raw --work-dir /private/tmp/liquid-pytorch-vendor
  cargo xtask prepare-liquid --source /private/tmp/liquid-pytorch-raw
  cargo xtask stage-liquid

Requires Apple Silicon macOS with Rosetta, Xcode command-line tools, CMake,
and an already verified shared
model/tokenizer. It explicitly downloads SHA256-pinned official LibTorch archives
and official wheels used ONLY to extract distribution notices, never to install
Python. --offline requires those archives in WORK/downloads. The upstream
LibTorch index does not publish checksums: its pins below are locally observed
hashes of the reviewed official HTTPS downloads, not distributor signatures.
Output native runtimes are thin binaries; the universal app chooses the matching
one. Apple Silicon Liquid needs macOS 14; Intel uses the app's macOS 12 floor.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import platform
import shutil
import subprocess
import tempfile
import urllib.request
import zipfile

HERE = Path(__file__).resolve().parent
CANONICAL_FIXTURE_SHA256 = "3567a30d66d213ad47a3fbd7cbedad4974ea9b6e19037326da82ee5050159dc2"
DISTRIBUTIONS = {
    "aarch64-apple-darwin": {
        "arch": "arm64", "version": "2.14.1", "minimum_macos": [14, 0], "openmp": "libomp.dylib",
        "archive": ("https://download.pytorch.org/libtorch/cpu/libtorch-macos-arm64-2.14.1.zip", 103834077,
                    "6ab4e92bed813981cb26434db0ea12aaae7ce7c548d031a5b25032a286de1b58"),
        "notices_wheel": ("https://files.pythonhosted.org/packages/4b/3c/379349820e9a6e713826de3d0b88f07728541bdcabe2a3afd128871cdc4b/torch-2.14.1-cp312-cp312-macosx_14_0_arm64.whl", 127307099,
                          "420dbf314c180ee4b86e9bc00aee5746a7d6e5bacdd7df925af671ed393f0b2e"),
    },
    "x86_64-apple-darwin": {
        "arch": "x86_64", "version": "2.2.2", "minimum_macos": [12, 0], "openmp": "libiomp5.dylib",
        "archive": ("https://download.pytorch.org/libtorch/cpu/libtorch-macos-x86_64-2.2.2.zip", 180532633,
                    "03a8066ee79baef6225bc3665fd3b0b7c4c11ac024086457974751bebdfe43c1"),
        "notices_wheel": ("https://files.pythonhosted.org/packages/79/78/29dcab24a344ffd9ee9549ec0ab2c7885c13df61cde4c65836ee275efaeb/torch-2.2.2-cp312-none-macosx_10_9_x86_64.whl", 150797270,
                          "eb4d6e9d3663e26cd27dc3ad266b34445a16b54908e74725adb241aa56987533"),
    },
}
LLVM_OPENMP = ("https://raw.githubusercontent.com/llvm/llvm-project/llvmorg-20.1.8/openmp/LICENSE.TXT", 19741,
               "fdad1758a9e1f9d5a81e18879b3406772115edc92c24bfa36b70c654f325e8e4")
INTEL_OPENMP = ("https://files.pythonhosted.org/packages/09/39/fcfc320db389a41d5a937d03b3221645833553ddae1efc20c7abef4a5512/intel_openmp-2022.2.0-py2.py3-none-macosx_10_15_x86_64.macosx_11_0_x86_64.whl", 751358,
                "4bef6593803da81a0a1f9962225688a331f118cb6b5107de8702258a0acac159")


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, value):
    temporary = Path(path).with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def download(pin, downloads, offline):
    url, size, sha = pin
    path = downloads / url.rsplit("/", 1)[1]
    if not path.exists():
        if offline:
            raise ValueError("Missing pinned offline download: " + path.name)
        temporary = path.with_suffix(path.suffix + ".partial")
        try:
            with urllib.request.urlopen(url, timeout=90) as source, temporary.open("wb") as output:
                remaining = size + 1
                while remaining:
                    chunk = source.read(min(1024 * 1024, remaining))
                    if not chunk:
                        break
                    output.write(chunk)
                    remaining -= len(chunk)
            if temporary.stat().st_size != size or digest(temporary) != sha:
                raise ValueError("Downloaded artifact checksum mismatch: " + path.name)
            temporary.replace(path)
        finally:
            temporary.unlink(missing_ok=True)
    if path.stat().st_size != size or digest(path) != sha:
        raise ValueError("Cached artifact checksum mismatch: " + path.name)
    return path


def extract_vendor(path, destination):
    if destination.exists():
        # Never trust a previously modified vendor tree with this archive's hash.
        shutil.rmtree(destination)
    destination.mkdir(parents=True)
    with zipfile.ZipFile(path) as archive:
        for info in archive.infolist():
            name = PurePosixPath(info.filename)
            if name.is_absolute() or ".." in name.parts or (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError("Unsafe native archive member")
        bad = archive.testzip()
        if bad:
            raise ValueError("Native archive CRC validation failed")
        archive.extractall(destination)
    return destination / "libtorch"


def decode_notice(value):
    try:
        text = value.decode("utf8")
    except UnicodeDecodeError:
        # Intel's original third-party-programs notice is Windows-1252.
        text = value.decode("cp1252")
    return text.replace("\r\n", "\n").replace("\r", "\n")


def create_notices(target, settings, wheel, extra, destination):
    url, _, sha = settings["notices_wheel"]
    sections = ["PyTorch " + settings["version"] + " native runtime notices for " + target,
                "Official wheel: " + url, "SHA256: " + sha,
                "These notices are included conservatively in full; the native bundle contains no Python runtime."]
    with zipfile.ZipFile(wheel) as archive:
        names = [name for name in archive.namelist() if ".dist-info/" in name
                 and any(part in ["license", "licenses", "notice", "notices"]
                         for part in name.lower().split("/")) and not name.endswith("/")]
        if not names:
            raise ValueError("Official wheel is missing its distribution notices")
        for name in sorted(names):
            sections += ["\n===== " + name + " =====\n", decode_notice(archive.read(name))]
    if target == "aarch64-apple-darwin":
        openmp = extra.read_text()
    else:
        parts = ["Intel OpenMP 2022.2 distribution companion notices (the native library comes from the pinned official LibTorch archive)."]
        with zipfile.ZipFile(extra) as archive:
            for name in sorted(archive.namelist()):
                if "/licensing/" in name or (".dist-info/" in name and "LICENSE" in name):
                    parts += ["\n===== " + name + " =====\n", decode_notice(archive.read(name))]
        openmp = "\n".join(parts) + "\n"
    # Keep exactly the same rendering as the reviewed native distribution bundle.
    destination.write_text("\n".join(sections) + "\n\n===== OpenMP runtime additional notices =====\n" + openmp)


def command(*arguments, env=None):
    subprocess.run([str(value) for value in arguments], check=True, env=env)


def runtime_names(settings):
    return ["liquid-pytorch", "libc10.dylib", "libtorch.dylib", "libtorch_cpu.dylib", settings["openmp"]]


def native_rpaths(load_commands):
    lines = load_commands.splitlines()
    paths = []
    for index, line in enumerate(lines):
        if line.strip() == "cmd LC_RPATH":
            for candidate in lines[index + 1:index + 5]:
                if candidate.strip().startswith("path "):
                    paths.append(candidate.strip()[5:].split(" (offset", 1)[0])
                    break
    return paths


def minimum_os(load_commands):
    lines = load_commands.splitlines()
    for index, line in enumerate(lines):
        if line.strip() in ["cmd LC_BUILD_VERSION", "cmd LC_VERSION_MIN_MACOSX"]:
            for candidate in lines[index + 1:index + 8]:
                if candidate.strip().startswith(("minos ", "version ")):
                    return candidate.split()[1]
    raise ValueError("Native file has no macOS minimum-version command")


def version_tuple(value):
    return tuple((list(map(int, value.split("."))) + [0, 0])[:3])


def normalization_plan(name, names, own_id, dependencies, rpaths):
    """Remove developer paths without relying on a machine's DYLD environment."""
    plan = []
    if own_id and own_id != "@rpath/" + name:
        plan.append(("-id", "@rpath/" + name))
    needs_rpath = False
    for dependency in dependencies:
        if dependency == own_id or dependency.startswith(("/usr/lib/", "/System/Library/")):
            continue
        basename = PurePosixPath(dependency).name
        if basename not in names:
            raise ValueError("Native dependency lies outside the bundled runtime closure")
        if dependency not in ["@rpath/" + basename, "@loader_path/" + basename]:
            plan.append(("-change", dependency, "@loader_path/" + basename))
        elif dependency.startswith("@rpath/"):
            needs_rpath = True
    for entry in rpaths:
        if entry != "@loader_path":
            plan.append(("-delete_rpath", entry))
    if needs_rpath and "@loader_path" not in rpaths:
        plan.append(("-add_rpath", "@loader_path"))
    return plan


def inspect_native(path):
    def output(*args):
        return subprocess.check_output([str(value) for value in args], text=True)
    ids = output("/usr/bin/otool", "-D", path).splitlines()
    own_id = ids[1].strip() if len(ids) > 1 else None
    dependencies = [line.strip().split(" (compatibility", 1)[0]
                    for line in output("/usr/bin/otool", "-L", path).splitlines()[1:]
                    if line.startswith("\t")]
    load_commands = output("/usr/bin/otool", "-l", path)
    return {"own_id": own_id, "dependencies": dependencies,
            "rpaths": native_rpaths(load_commands), "minimum_macos": minimum_os(load_commands),
            "architecture": output("/usr/bin/lipo", "-archs", path).strip()}


def normalize_native(path, names, settings):
    before = inspect_native(path)
    for action in normalization_plan(path.name, names, before["own_id"],
                                     before["dependencies"], before["rpaths"]):
        command("/usr/bin/install_name_tool", *action, path)
    after = inspect_native(path)
    if normalization_plan(path.name, names, after["own_id"], after["dependencies"], after["rpaths"]):
        raise ValueError("Native dependency normalization did not converge")
    minimum = ".".join(map(str, settings["minimum_macos"]))
    if (after["architecture"] != settings["arch"]
            or version_tuple(after["minimum_macos"]) > version_tuple(minimum)
            or (path.name == "liquid-pytorch" and version_tuple(after["minimum_macos"]) != version_tuple(minimum))):
        raise ValueError("Native architecture or minimum macOS does not match its target")
    return after


def validate_smoke(target, stdout):
    rows = [json.loads(line) for line in stdout.splitlines()]
    if len(rows) != 2:
        raise ValueError("Native helper smoke test returned an unexpected response count")
    ready, prediction = rows
    probabilities = prediction.get("error_probs", [])
    if (ready.get("ready") is not True or ready.get("protocol") != 1
            or ready.get("target") != target or ready.get("threads") != 4
            or prediction.get("id") != 1 or prediction.get("ok") is not True
            or prediction.get("best_tags") != [0] * 6 or len(probabilities) != 6
            or any(not math.isfinite(value) or not 0 <= value <= 1 for value in probabilities)):
        raise ValueError("Native helper failed its loaded-model smoke test")


def smoke_runtime(target, runtime, model):
    # No developer library paths or Python can participate in this smoke test.
    environment = {key: value for key, value in os.environ.items()
                   if not key.startswith(("DYLD_", "PYTHON"))}
    environment["PATH"] = "/usr/bin:/bin"
    result = subprocess.run([str(runtime / "liquid-pytorch"), str(model), "4"],
                            input="1 1 7580 12693 938 11534 1701\n", text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            check=True, timeout=60, env=environment)
    validate_smoke(target, result.stdout)


def build_runtime(target, settings, vendor, source, work):
    build = work / ("build-" + target)
    minimum = ".".join(map(str, settings["minimum_macos"]))
    environment = dict(os.environ, MACOSX_DEPLOYMENT_TARGET=minimum)
    command("cmake", "-S", HERE / "liquid-pytorch-helper", "-B", build,
            "-DCMAKE_BUILD_TYPE=Release", "-DBUILD_TESTING=OFF",
            "-DCMAKE_CXX_COMPILER=/usr/bin/clang++", "-DCMAKE_PREFIX_PATH=" + str(vendor),
            "-DCMAKE_OSX_ARCHITECTURES=" + settings["arch"],
            "-DCMAKE_OSX_DEPLOYMENT_TARGET=" + minimum, env=environment)
    command("cmake", "--build", build, "--config", "Release", "--parallel", "2", env=environment)
    runtime_root = source / "runtime"
    runtime_root.mkdir(exist_ok=True)
    destination = runtime_root / target
    if destination.exists():
        raise ValueError("Native destination already exists; remove it explicitly before rebuilding: " + str(destination))
    with tempfile.TemporaryDirectory(prefix=".liquid-native-", dir=runtime_root) as temporary:
        staged = Path(temporary)
        inspections = {}
        for name in runtime_names(settings):
            original = build / name if name == "liquid-pytorch" else vendor / "lib" / name
            shutil.copyfile(original, staged / name)
            (staged / name).chmod(0o755)
            inspections[name] = normalize_native(staged / name, runtime_names(settings), settings)
            command("/usr/bin/strip", "-S", "-x", staged / name)
            command("/usr/bin/codesign", "--force", "--sign", "-", "--timestamp=none", staged / name)
            command("/usr/bin/codesign", "--verify", "--strict", staged / name)
        smoke_runtime(target, staged, source / "liquid.pt")
        staged.rename(destination)
    return destination, inspections


def validate_source(source):
    provenance = json.loads((source / "PROVENANCE.json").read_text())
    parity = provenance.get("parity", {})
    for name, key in [("liquid.pt", "model_sha256"), ("tokenizer.json", "tokenizer_sha256")]:
        value = digest(source / name)
        if provenance.get(key) != value or parity.get(key) != value:
            raise ValueError("Shared source hashes differ from passing parity")
    shapes = parity.get("shape_boundaries", [])
    if (parity.get("matched", 0) != 268 or parity.get("compared_reference_steps", 0) != 427
            or parity.get("fixture_sha256") != CANONICAL_FIXTURE_SHA256
            or parity.get("mismatches") != []
            or not all(parity.get(key) is True for key in
                       ["parameter_fp16_roundtrip_bit_exact", "reference_unchanged", "buffers_unchanged"])
            or not 0 <= parity.get("max_error_probability_delta", 1) <= 1e-4
            or [shape.get("sequence") for shape in shapes] != [1, 2, 8, 32, 127, 128]
            or not all(shape.get("tags_match") is True and 0 <= shape.get("max_error_probability_delta", 1) <= 1e-4
                       for shape in shapes)):
        raise ValueError("Native build requires passing canonical 268-case/427-pass correction parity")
    return provenance


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--work-dir", type=Path, required=True)
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()
    if platform.system() != "Darwin" or platform.machine() != "arm64":
        parser.error("building and smoke-testing both helpers requires Apple Silicon macOS with Rosetta and Xcode tools")
    source, work = args.source.resolve(), args.work_dir.resolve()
    provenance = validate_source(source)
    downloads = work / "downloads"
    downloads.mkdir(parents=True, exist_ok=True)
    (source / "licenses").mkdir(exist_ok=True)
    runtimes = []
    for target, settings in DISTRIBUTIONS.items():
        archive = download(settings["archive"], downloads, args.offline)
        vendor = extract_vendor(archive, work / ("vendor-" + target))
        wheel = download(settings["notices_wheel"], downloads, args.offline)
        extra_pin = LLVM_OPENMP if target == "aarch64-apple-darwin" else INTEL_OPENMP
        extra = download(extra_pin, downloads, args.offline)
        notices = source / "licenses" / (target + ".txt")
        create_notices(target, settings, wheel, extra, notices)
        runtime, inspections = build_runtime(target, settings, vendor, source, work)
        files = [{"name": name, "bytes": (runtime / name).stat().st_size,
                  "sha256": digest(runtime / name)} for name in runtime_names(settings)]
        runtimes.append({"target": target, "libtorch_version": settings["version"],
                         "minimum_macos": settings["minimum_macos"],
                         "archive_url": settings["archive"][0], "archive_sha256": settings["archive"][2],
                         "archive_digest_source": "reviewed official HTTPS download; no upstream-published checksum",
                         "helper_sha256": digest(runtime / "liquid-pytorch"),
                         "notices_sha256": digest(notices), "files": files,
                         "inspection": inspections, "loaded_model_smoke_passed": True,
                         "notices_wheel_sha256": settings["notices_wheel"][2],
                         "openmp_notice_sha256": extra_pin[2],
                         "helper_source_sha256": digest(HERE / "liquid-pytorch-helper/main.cpp"),
                         "helper_cmake_sha256": digest(HERE / "liquid-pytorch-helper/CMakeLists.txt"),
                         "helper_protocol_sha256": digest(HERE / "liquid-pytorch-helper/protocol.hpp"),
                         "builder_sha256": digest(__file__)})
    provenance["runtimes"] = runtimes
    write_json(source / "PROVENANCE.json", provenance)
    print("Native raw payload ready:", source)


if __name__ == "__main__":
    main()
