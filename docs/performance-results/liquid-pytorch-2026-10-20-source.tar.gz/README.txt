Historical native PyTorch experiment, superseded by native ONNX Runtime at user request.
No model weights, Python environment, LibTorch binaries or wheels are stored here.
production-source is the root snapshot taken before runtime switched to ONNX, not current source.
The prototype compact model SHA bd3a4e8ccf546b9a6febbf379d8b0110a74f6b5bab77d3b11992989a89e68ee4 passed all268corrections/427rawpasses and nativeARM/Intel runs.
The checked-in exporter also completed a fresh export and proved all serialized parameter/buffer bits after FP32 reload; its subsequent full verification was interrupted at user-directed architecture switch and is NOT a pass.
Both the prototype and unfinished fresh model remain outside Git under /private/tmp for this session.
Use the active scripts/export-liquid-onnx.py and scripts/build-liquid-onnx.py for current production.
