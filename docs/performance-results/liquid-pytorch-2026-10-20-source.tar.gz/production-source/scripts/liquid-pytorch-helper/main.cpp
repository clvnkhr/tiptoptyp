#include "protocol.hpp"

#include <ATen/Parallel.h>
#include <torch/csrc/jit/passes/freeze_module.h>
#include <torch/script.h>

#include <cmath>
#include <iomanip>
#include <iostream>
#include <stdexcept>

namespace {

#if defined(__APPLE__) && defined(__aarch64__)
constexpr const char* kTarget = "aarch64-apple-darwin";
#elif defined(__APPLE__) && defined(__x86_64__)
constexpr const char* kTarget = "x86_64-apple-darwin";
#else
#error "The packaged Liquid helper supports macOS arm64 and x86_64."
#endif

void write_identifier(std::optional<std::uint64_t> identifier) {
  if (identifier) {
    std::cout << *identifier;
  } else {
    std::cout << "null";
  }
}

// Messages are fixed strings. Never forward model exceptions, source text,
// token IDs, or filesystem paths to a protocol response or a diagnostic log.
void write_error(std::optional<std::uint64_t> identifier, const char* message) {
  std::cout << "{\"id\":";
  write_identifier(identifier);
  std::cout << ",\"ok\":false,\"error\":\"" << message << "\"}"
            << std::endl;
}

void predict(torch::jit::Module& model,
             liquid::protocol::Request& request) {
  const auto length = static_cast<std::int64_t>(request.tokens.size());
  // CPU operations complete before this request's storage is released.
  auto input = torch::from_blob(
      request.tokens.data(), {1, length},
      torch::TensorOptions().dtype(torch::kInt64).device(torch::kCPU));
  auto mask = torch::ones_like(input);
  auto result = model.forward({input, mask});
  if (!result.isTuple() || result.toTuple()->elements().size() != 2) {
    throw std::runtime_error("invalid prediction");
  }
  const auto& elements = result.toTuple()->elements();
  if (!elements[0].isTensor() || !elements[1].isTensor()) {
    throw std::runtime_error("invalid prediction");
  }
  auto tags = elements[0].toTensor();
  auto probabilities = elements[1].toTensor();
  if (!tags.device().is_cpu() || !probabilities.device().is_cpu() ||
      tags.scalar_type() != torch::kInt64 ||
      probabilities.scalar_type() != torch::kFloat32 ||
      tags.sizes() != input.sizes() || probabilities.sizes() != input.sizes()) {
    throw std::runtime_error("invalid prediction");
  }
  // The detector result is a strided slice of its two-class softmax.
  tags = tags.contiguous();
  probabilities = probabilities.contiguous();
  const auto* tag_data = tags.data_ptr<std::int64_t>();
  const auto* probability_data = probabilities.data_ptr<float>();
  for (std::int64_t i = 0; i < length; ++i) {
    if (tag_data[i] < 0 || tag_data[i] >= liquid::protocol::kTagCount ||
        !std::isfinite(probability_data[i]) || probability_data[i] < 0 ||
        probability_data[i] > 1) {
      throw std::runtime_error("invalid prediction");
    }
  }
  std::cout << "{\"id\":";
  write_identifier(request.id);
  std::cout << ",\"ok\":true,\"best_tags\":[";
  for (std::int64_t i = 0; i < length; ++i) {
    if (i != 0) {
      std::cout << ',';
    }
    std::cout << tag_data[i];
  }
  std::cout << "],\"error_probs\":[";
  for (std::int64_t i = 0; i < length; ++i) {
    if (i != 0) {
      std::cout << ',';
    }
    // Nine significant digits round-trip a float32 without extra payload.
    std::cout << std::setprecision(9) << probability_data[i];
  }
  std::cout << "]}" << std::endl;
}

}  // namespace

int main(int argc, char** argv) {
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);
  int threads;
  if (argc != 3 ||
      !liquid::protocol::parse_integer(std::string_view(argv[2]), threads) ||
      threads < 1 || threads > 8) {
    std::cerr << "Liquid requires a model and a CPU thread count from 1 to 8.\n";
    return 2;
  }
  try {
    at::set_num_threads(threads);
    at::set_num_interop_threads(1);
    c10::InferenceMode inference;
    auto model = torch::jit::load(argv[1], torch::kCPU);
    model.to(torch::kFloat32);
    model.eval();
    torch::jit::freeze_module_inplace(&model);
    std::cout << "{\"ready\":true,\"protocol\":1,\"target\":\"" << kTarget
              << "\",\"threads\":" << threads << '}' << std::endl;
    std::string line;
    line.reserve(liquid::protocol::kMaximumLineBytes);
    bool too_long;
    while (liquid::protocol::read_line(std::cin, line, too_long)) {
      auto request = liquid::protocol::parse_request(line, too_long);
      if (request.error != liquid::protocol::Error::None) {
        write_error(request.id, liquid::protocol::message(request.error));
        if (!std::cout) {
          return 1;
        }
        continue;
      }
      try {
        predict(model, request);
      } catch (...) {
        write_error(request.id, "Liquid inference failed.");
        return 1;
      }
      if (!std::cout) {
        return 1;
      }
    }
    return std::cin.bad() ? 1 : 0;
  } catch (...) {
    std::cerr << "Liquid model could not load.\n";
    return 1;
  }
}
