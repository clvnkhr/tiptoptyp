from pathlib import Path
import copy,hashlib,importlib.util,json,sys,time,zipfile
ROOT=Path('/Users/calvinkhor/Documents/GitHub/mytypst');OUT=Path('/private/tmp/liquid-pytorch-native-20261020')
spec=importlib.util.spec_from_file_location('compact_reference_worker',ROOT/'scripts/liquid-grammar-worker.py');worker=importlib.util.module_from_spec(spec);sys.modules[spec.name]=worker;spec.loader.exec_module(worker)
adapter=worker.load_adapter(Path('/private/tmp/liquid-integration-runtime-20261020/models'),4).adapter
import torch,numpy as np

def tensor_sha(value):return hashlib.sha256(value.detach().contiguous().numpy().tobytes()).hexdigest()
reference_hashes={name:tensor_sha(value) for name,value in adapter.model.named_parameters()}
reference_buffers={name:tensor_sha(value) for name,value in adapter.model.named_buffers()}
reference_dtype={name:str(value.dtype) for name,value in adapter.model.named_parameters()}
class Export(torch.nn.Module):
 def __init__(self,model):super().__init__();self.model=model
 def forward(self,input_ids,attention_mask):
  result=self.model(input_ids,attention_mask)
  return result['label_logits'].argmax(-1),result['detect_logits'].softmax(-1)[...,1]
model=copy.deepcopy(adapter.model).float().eval()
for name,parameter in model.named_parameters():assert parameter.data_ptr()!=dict(adapter.model.named_parameters())[name].data_ptr()
model.encoder.set_attn_implementation('eager')
assert model.encoder.config._attn_implementation=='eager'
# Hugging Face's dynamic cache modules contain numeric SHA path components,
# which TorchScript's serialized Python-name parser cannot read unfrozen.
# Give only this independent clone safe subclasses; never mutate shared classes.
safe_types={}
for child in model.modules():
 original_type=type(child)
 if any(not component.isidentifier() for component in original_type.__module__.split('.')):
  safe_type=safe_types.get(original_type)
  if safe_type is None:
   safe_type=type(original_type.__name__,(original_type,),{'__module__':'liquid_native_portable'})
   safe_types[original_type]=safe_type
  child.__class__=safe_type
assert model.encoder.config._attn_implementation=='eager'
example=torch.tensor([[1]+adapter.tokenizer.encode('She go to school every day .',add_special_tokens=False)],dtype=torch.int64)
with torch.inference_mode(): traced=torch.jit.trace(Export(model).eval(),(example,torch.ones_like(example)),strict=True,check_trace=False)
ops=torch.jit.export_opnames(traced)
assert not any('scaled_dot_product' in name for name in ops),ops
(OUT/'compact-operators.json').write_text(json.dumps(ops,indent=2)+'\n')
# Mutate only the traced independent clone; no freeze or optimizer may fold the
# future FP32 arithmetic into a doubled-size on-disk constant table.
converted=[];retained=[];total_saved=0
for name,parameter in traced.named_parameters():
 value=parameter.detach()
 if value.dtype==torch.float32:
  half=value.to(torch.float16)
  exact=torch.equal(value.view(torch.int32),half.float().view(torch.int32))
  if exact:
   total_saved+=value.numel()*2
   converted.append(dict(name=name,elements=value.numel(),float32_sha256=tensor_sha(value)))
   parameter.data=half
  else:retained.append(dict(name=name,dtype=str(value.dtype),reason='not bit-exact FP16 round trip'))
 else:retained.append(dict(name=name,dtype=str(value.dtype),reason='not FP32'))
buffers_before={name:tensor_sha(value) for name,value in traced.named_buffers()}
path=OUT/'liquid-compact.pt';temporary=OUT/'liquid-compact-building.pt';traced.save(str(temporary));temporary.replace(path)
print('SAVED',path.stat().st_size,'parameters_compacted',len(converted),'retained',len(retained),flush=True)
with zipfile.ZipFile(path) as archive:versions={n:archive.read(n).decode().strip() for n in archive.namelist() if n.endswith('/version') or n.endswith('/byteorder')}
# Free the builder clone before loading the storage form independently.
del traced,model
loaded=torch.jit.load(str(path),map_location='cpu').eval()
loaded_storage_dtypes={name:str(value.dtype) for name,value in loaded.named_parameters()}
loaded.to(dtype=torch.float32)
for name,parameter in loaded.named_parameters():
 original_name=name.removeprefix('model.')
 assert str(parameter.dtype)==reference_dtype[original_name]
 assert tensor_sha(parameter)==reference_hashes[original_name],name
for name,buffer in loaded.named_buffers():assert tensor_sha(buffer)==buffers_before[name],name
assert {name:tensor_sha(value) for name,value in adapter.model.named_parameters()}==reference_hashes
assert {name:tensor_sha(value) for name,value in adapter.model.named_buffers()}==reference_buffers
assert adapter.model.encoder.config._attn_implementation=='sdpa'
print('RELOADED TO FP32: all parameter bits and buffer hashes match; reference unchanged',flush=True)
shape_results=[]
with torch.inference_mode():
 for length in [1,2,8,32,127,128]:
  ids=torch.ones([1,length],dtype=torch.int64)
  ref=adapter.model(ids,ids);tags,probs=loaded(ids,ids)
  row=dict(length=length,tags_match=torch.equal(tags,ref['label_logits'].argmax(-1)),max_error_probability_delta=float(torch.max(torch.abs(probs-ref['detect_logits'].softmax(-1)[...,1]))))
  shape_results.append(row);print('Shape',row,flush=True)
 goldens=json.loads(Path('/private/tmp/liquid-onnx-20261020/final/goldens.json').read_text())
 count=0;max_delta=0.;mismatches=[]
 for case in goldens['cases']:
  for pass_index,step in enumerate(case['reference_passes']):
   ids=torch.tensor([step['input_ids']],dtype=torch.int64);tags,probs=loaded(ids,torch.ones_like(ids))
   delta=float(np.max(np.abs(probs.numpy()[0]-np.asarray(step['error_probs']))));max_delta=max(max_delta,delta)
   same=tags.tolist()[0]==step['best_tags']
   if not same or delta>1e-4:mismatches.append(dict(id=case['id'],pass_index=pass_index,tags_match=same,max_error_probability_delta=delta))
   count+=1
  if count%20==0:print('Verified passes',count,flush=True)
 # Exercise the exact same source tokenization/refinement/untokenization loop,
 # with only its raw model call replaced by the reloaded native graph.
 s=importlib.util.spec_from_file_location('onnx_export',ROOT/'scripts/export-liquid-onnx.py');e=importlib.util.module_from_spec(s);sys.modules[s.name]=e;s.loader.exec_module(e)
 def step(ids):
  value=torch.tensor([ids],dtype=torch.int64)
  a,b=loaded(value,torch.ones_like(value));return a.numpy()[0],b.numpy()[0]
 final=[]
 for index,case in enumerate(goldens['cases']):
  actual=e.correct(adapter,case['text'],step)
  final.append(dict(id=case['id'],match=actual==case['reference_corrected'],actual=actual,expected=case['reference_corrected']))
  if (index+1)%40==0:print('Verified corrections',index+1,flush=True)
with path.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
report=dict(torch=torch.__version__,model_bytes=path.stat().st_size,model_sha256=sha,archive_versions=versions,parameter_fp16_roundtrip_bit_exact=True,reference_unchanged=True,converted_parameters=converted,retained_parameters=retained,buffers_unchanged=True,loaded_storage_dtypes=loaded_storage_dtypes,saved_parameter_bytes=total_saved,required_load_action='module.to(torch.float32) once before inference; graph is intentionally unfrozen on disk',arithmetic='float32',threads=4,trace_sequence=8,shape_results=shape_results,reference_cases=len(goldens['cases']),reference_passes=count,max_error_probability_delta=max_delta,raw_mismatches=mismatches,corrected_match=sum(x['match'] for x in final),correction_mismatches=[x for x in final if not x['match']],correction_results=final)
(OUT/'compact-torchscript-parity.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['converted_parameters','retained_parameters','loaded_storage_dtypes','correction_results']}),flush=True)
assert not mismatches and all(x['tags_match'] and x['max_error_probability_delta']<=1e-4 for x in shape_results) and all(x['match'] for x in final)
