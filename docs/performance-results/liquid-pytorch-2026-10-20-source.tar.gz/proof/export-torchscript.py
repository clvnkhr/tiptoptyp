from pathlib import Path
import hashlib, importlib.util, json, sys, time, zipfile
ROOT=Path('/Users/calvinkhor/Documents/GitHub/mytypst')
OUT=Path('/private/tmp/liquid-pytorch-native-20261020')
MODEL_CACHE=Path('/private/tmp/liquid-integration-runtime-20261020/models')
spec=importlib.util.spec_from_file_location('reference_worker',ROOT/'scripts/liquid-grammar-worker.py')
worker=importlib.util.module_from_spec(spec);sys.modules[spec.name]=worker;spec.loader.exec_module(worker)
started=time.perf_counter();adapter=worker.load_adapter(MODEL_CACHE,4).adapter
import torch
import numpy as np
class Export(torch.nn.Module):
    def __init__(self,model):super().__init__();self.model=model
    def forward(self,input_ids,attention_mask):
        result=self.model(input_ids,attention_mask)
        return result['label_logits'].argmax(-1),result['detect_logits'].softmax(-1)[...,1]
adapter.model.encoder.set_attn_implementation('eager')
ids=torch.tensor([[1]+adapter.tokenizer.encode('She go to school every day .',add_special_tokens=False)],dtype=torch.int64)
trace_length=ids.shape[1]
with torch.inference_mode():
    traced=torch.jit.trace(Export(adapter.model).eval(),(ids,torch.ones_like(ids)),strict=True,check_trace=False)
    frozen=torch.jit.freeze(traced.eval(),optimize_numerics=False)
    frozen.save(str(OUT/'liquid-eager.pt'))
print('Exported',time.perf_counter()-started,flush=True)
ops=torch.jit.export_opnames(frozen)
(OUT/'operators.json').write_text(json.dumps(ops,indent=2)+'\n')
with zipfile.ZipFile(OUT/'liquid-eager.pt') as archive:
    versions={n:archive.read(n).decode().strip() for n in archive.namelist() if n.endswith('/version') or n.endswith('/byteorder')}
print('Archive',versions,'operators',len(ops),flush=True)
# Compare the traced/frozen implementation with original SDPA on dynamic boundaries.
adapter.model.encoder.set_attn_implementation('sdpa')
shape_results=[]
with torch.inference_mode():
    for length in [1,2,8,32,127,128]:
        shape=torch.ones([1,length],dtype=torch.int64)
        ref=adapter.model(shape,shape)
        expected_tags=ref['label_logits'].argmax(-1)
        expected_prob=ref['detect_logits'].softmax(-1)[...,1]
        tags,prob=frozen(shape,shape)
        row=dict(length=length,tags_match=torch.equal(tags,expected_tags),max_error_probability_delta=float(torch.max(torch.abs(prob-expected_prob))))
        shape_results.append(row);print('Shape',row,flush=True)
    goldens=json.loads(Path('/private/tmp/liquid-onnx-20261020/final/goldens.json').read_text())
    count=0;max_delta=0.;mismatches=[]
    for case in goldens['cases']:
        for pass_index,step in enumerate(case['reference_passes']):
            ids=torch.tensor([step['input_ids']],dtype=torch.int64)
            tags,probs=frozen(ids,torch.ones_like(ids))
            delta=float(np.max(np.abs(probs.numpy()[0]-np.asarray(step['error_probs']))))
            max_delta=max(max_delta,delta)
            same=tags.tolist()[0]==step['best_tags']
            if not same or delta>1e-4:mismatches.append(dict(id=case['id'],pass_index=pass_index,tags_match=same,max_error_probability_delta=delta))
            count+=1
        if count%20==0:print('Verified passes',count,flush=True)
with (OUT/'liquid-eager.pt').open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
report=dict(torch=torch.__version__,model_bytes=(OUT/'liquid-eager.pt').stat().st_size,model_sha256=digest,archive_versions=versions,operator_names=ops,arithmetic='float32',threads=4,export_mode='torch.jit.trace strict=True, check_trace=False; freeze optimize_numerics=False; no optimize_for_inference',trace_sequence=trace_length,trace_limitations=['Python current-sequence>0 and shortconv result-size comparisons frozen; seq1 recurrent mask branch traced atseq8; originalSDPA dynamic boundarychecks validate1..128 required shapes','No padding batching; supportedproductionmask allonesbatch1'],shape_results=shape_results,reference_cases=len(goldens['cases']),reference_passes=count,max_error_probability_delta=max_delta,mismatches=mismatches)
(OUT/'torchscript-parity.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['operator_names','trace_limitations']}),flush=True)
assert not mismatches and all(r['tags_match'] and r['max_error_probability_delta']<=1e-4 for r in shape_results)
