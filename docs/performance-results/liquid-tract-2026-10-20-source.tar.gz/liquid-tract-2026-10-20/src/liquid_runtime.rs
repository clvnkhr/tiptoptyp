//! Optional native grammar model. The shared client is inert until an explicit
//! selected-text request runs on an application worker; installation is offline.
use crate::{
    bundled_payload::codec,
    liquid_text::{Prediction, TextProcessor},
};
use sha2::{Digest, Sha256};
use std::{
    fs,
    io::{Read, Write},
    path::{Path, PathBuf},
    sync::{Arc, LazyLock, Mutex},
};
use tract_onnx::prelude::*;

#[path = "../build_support/liquid_manifest.rs"]
mod manifest;

#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct Config {
    pub(crate) directory: PathBuf,
    pub(crate) threads: u8,
}
impl Config {
    pub(crate) fn from_settings(settings: &crate::settings::AppSettings) -> Result<Self, String> {
        validate_settings(&settings.liquid_cache_directory, settings.liquid_threads)?;
        let directory = if settings.liquid_cache_directory.trim().is_empty() {
            default_directory()?
        } else {
            PathBuf::from(settings.liquid_cache_directory.trim())
        };
        Ok(Self {
            directory,
            threads: settings.liquid_threads,
        })
    }
    fn model_directory(&self) -> PathBuf {
        self.directory.join("onnx").join(manifest::MODEL_ID)
    }
}

pub(crate) fn validate_settings(directory: &str, threads: u8) -> Result<(), String> {
    if directory.len() > 4096
        || directory.chars().any(char::is_control)
        || (!directory.trim().is_empty() && !Path::new(directory.trim()).is_absolute())
    {
        return Err("liquid_cache_directory: choose an absolute folder path, or leave it empty for the app data folder.".into());
    }
    if !(1..=8).contains(&threads) {
        return Err("liquid_threads: choose between 1 and 8 CPU threads.".into());
    }
    Ok(())
}
fn default_directory() -> Result<PathBuf, String> {
    #[cfg(target_os = "macos")]
    let base = std::env::var_os("HOME")
        .map(|home| PathBuf::from(home).join("Library/Application Support"));
    #[cfg(target_os = "windows")]
    let base = std::env::var_os("LOCALAPPDATA").map(PathBuf::from);
    #[cfg(not(any(target_os = "macos", target_os = "windows")))]
    let base = std::env::var_os("XDG_DATA_HOME")
        .map(PathBuf::from)
        .filter(|p| p.is_absolute())
        .or_else(|| std::env::var_os("HOME").map(|home| PathBuf::from(home).join(".local/share")));
    base.filter(|p| p.is_absolute())
        .map(|p| p.join("dev.tiptoptyp.editor/liquid"))
        .ok_or_else(|| {
            "Cannot find the application data folder. Choose a Liquid folder in Settings → Writing."
                .into()
        })
}

#[derive(Default)]
pub(crate) struct Client {
    model: Option<LoadedModel>,
}
/// Every editor window shares one lazily loaded native model. Constructing this
/// handle performs no filesystem, model loading, thread-pool or network work.
pub(crate) fn shared_client() -> Arc<Mutex<Client>> {
    static CLIENT: LazyLock<Arc<Mutex<Client>>> =
        LazyLock::new(|| Arc::new(Mutex::new(Client::default())));
    Arc::clone(&CLIENT)
}
impl Client {
    pub(crate) fn correct(
        &mut self,
        config: &Config,
        texts: &[String],
    ) -> Result<Vec<String>, String> {
        validate_input(texts)?;
        if self
            .model
            .as_ref()
            .is_some_and(|model| model.config != *config)
        {
            self.model = None;
        }
        if self.model.is_none() {
            self.model = Some(LoadedModel::load(config.clone())?);
        }
        let loaded = self.model.as_mut().unwrap();
        texts
            .iter()
            .map(|text| {
                loaded
                    .processor
                    .correct(text, |ids| loaded.inference.predict(ids))
            })
            .collect()
    }
    /// Explicit first-use expansion of the bundled portable model. No Python,
    /// package manager, shell command or download is involved.
    pub(crate) fn install(&mut self, config: &Config) -> Result<(), String> {
        self.model = None;
        let root = packaged_directory()?;
        install_from(&root, config)
    }
}
fn validate_input(texts: &[String]) -> Result<(), String> {
    if texts.is_empty()
        || texts.len() > 64
        || texts.iter().map(|s| s.chars().count()).sum::<usize>() > 16_384
    {
        return Err("Select between one and 64 short paragraphs, up to 16,384 characters.".into());
    }
    if texts
        .iter()
        .any(|text| text.chars().count() > 4096 || text.len() > 16 * 1024)
    {
        return Err(
            "A selected paragraph is too long for Liquid. Select shorter sentences.".into(),
        );
    }
    Ok(())
}
struct LoadedModel {
    config: Config,
    processor: TextProcessor,
    inference: NativeModel,
}
impl LoadedModel {
    fn load(config: Config) -> Result<Self, String> {
        // Excludes another app instance's explicit installer while its files are
        // published. Subsequent requests reuse the verified, resident model.
        let _lock = setup_lock(&config.directory)?;
        let root = config.model_directory();
        verify_model_directories(&config)?;
        let installed = read_manifest(&root).map_err(|_| {
            "Liquid is not installed. Choose Install Liquid to prepare its bundled model."
                .to_owned()
        })?;
        for file in &installed.files {
            verify_file(&root.join(&file.name), file.bytes, &file.sha256).map_err(|_| {
                "Liquid's model failed its integrity check. Choose Install Liquid to repair it."
                    .to_owned()
            })?;
        }
        let processor = TextProcessor::load(&root.join(manifest::TOKENIZER_NAME))?;
        let inference = NativeModel::load(&root.join(manifest::MODEL_NAME), config.threads)?;
        Ok(Self {
            config,
            processor,
            inference,
        })
    }
}
struct NativeModel {
    // Reuse the execution session as well as the optimized graph. Constructing
    // a fresh state per pass discards kernel scratch and output-store caches.
    state: TypedSimpleState,
}
impl NativeModel {
    fn load(path: &Path, threads: u8) -> Result<Self, String> {
        let options = tract_onnx::tract_core::runtime::RunOptions {
            executor: Some(tract_linalg::multithread::Executor::multithread_with_name(
                usize::from(threads),
                "liquid-inference",
            )),
            ..Default::default()
        };
        let model = tract_onnx::onnx()
            .model_for_path(path)
            .and_then(|model| model.into_optimized())
            .and_then(|model| model.into_runnable_with_options(&options))
            .map_err(|_| {
                "Cannot load Liquid's native model. Choose Install Liquid to repair it.".to_owned()
            })?;
        let state = model.spawn().map_err(|_| {
            "Cannot prepare Liquid's native model. Choose Install Liquid to repair it.".to_owned()
        })?;
        Ok(Self { state })
    }
    fn predict(&mut self, ids: &[i64]) -> Result<Prediction, String> {
        if ids.is_empty() || ids.len() > 128 {
            return Err(
                "A selected sentence is too long for Liquid. Select shorter sentences.".into(),
            );
        }
        let failure =
            || "Liquid could not check this selection. Try shorter, complete sentences.".to_owned();
        let ids_tensor = Tensor::from_shape(&[1, ids.len()], ids).map_err(|_| failure())?;
        let mask =
            Tensor::from_shape(&[1, ids.len()], &vec![1i64; ids.len()]).map_err(|_| failure())?;
        let outputs = match self.state.run(tvec!(ids_tensor.into(), mask.into())) {
            Ok(outputs) => outputs,
            Err(_) => {
                // A failed dynamic-shape run must not leave symbols or values
                // from this request in the next request's session.
                let _ = self.state.reset_turn();
                return Err(failure());
            }
        };
        if outputs.len() != 2 || outputs.iter().any(|value| value.shape() != [1, ids.len()]) {
            return Err(failure());
        }
        let tags = outputs[0]
            .to_plain_array_view::<i64>()
            .map_err(|_| failure())?;
        let probabilities = outputs[1]
            .to_plain_array_view::<f32>()
            .map_err(|_| failure())?;
        let tags = tags.iter().copied().collect::<Vec<_>>();
        let error_probabilities = probabilities.iter().copied().collect::<Vec<_>>();
        if tags.iter().any(|tag| *tag < 0)
            || error_probabilities
                .iter()
                .any(|p| !p.is_finite() || !(0.0..=1.0).contains(p))
        {
            return Err(failure());
        }
        Ok(Prediction {
            tags,
            error_probabilities,
        })
    }
}

fn packaged_directory() -> Result<PathBuf, String> {
    let executable =
        std::env::current_exe().map_err(|_| "Cannot locate Liquid's bundled model.".to_owned())?;
    let candidates = crate::bundled_payload::resource_roots(&executable)
        .into_iter()
        .map(|root| root.join("liquid"))
        .collect::<Vec<_>>();
    #[cfg(not(feature = "production"))]
    let candidates = {
        let mut candidates = candidates;
        candidates.push(Path::new(env!("CARGO_MANIFEST_DIR")).join("toolchain/liquid"));
        candidates
    };
    candidates
        .into_iter()
        .find(|root| root.join(manifest::MANIFEST_NAME).is_file())
        .ok_or_else(|| {
            "Liquid setup cannot find its bundled model. Reinstall the complete app package."
                .to_owned()
        })
}
fn read_manifest(directory: &Path) -> Result<manifest::Manifest, String> {
    let path = directory.join(manifest::MANIFEST_NAME);
    if !fs::symlink_metadata(&path).is_ok_and(|metadata| {
        metadata.file_type().is_file() && metadata.len() <= manifest::MAX_MANIFEST_BYTES
    }) {
        return Err("Liquid manifest is missing or invalid".into());
    }
    let file = fs::File::open(path).map_err(|_| "Liquid manifest is missing".to_owned())?;
    let mut bytes = Vec::new();
    file.take(manifest::MAX_MANIFEST_BYTES + 1)
        .read_to_end(&mut bytes)
        .map_err(|_| "Cannot read Liquid manifest".to_owned())?;
    manifest::Manifest::parse(&bytes)
}
fn verify_file(path: &Path, bytes: u64, expected: &str) -> Result<(), String> {
    let metadata = fs::symlink_metadata(path).map_err(|_| "Liquid file is missing".to_owned())?;
    if !metadata.file_type().is_file() || metadata.len() != bytes {
        return Err("Liquid file has an invalid size or type".into());
    }
    let mut file = fs::File::open(path)
        .map_err(|_| "Cannot read Liquid file".to_owned())?
        .take(bytes + 1);
    let mut hasher = Sha256::new();
    let mut buffer = [0u8; 64 * 1024];
    let mut actual = 0u64;
    loop {
        let count = file
            .read(&mut buffer)
            .map_err(|_| "Cannot verify Liquid file".to_owned())?;
        if count == 0 {
            break;
        }
        actual += count as u64;
        hasher.update(&buffer[..count]);
    }
    if actual != bytes || format!("{:x}", hasher.finalize()) != expected {
        return Err("Liquid file checksum does not match".into());
    }
    Ok(())
}
fn verify_model_directories(config: &Config) -> Result<(), String> {
    for directory in [config.directory.join("onnx"), config.model_directory()] {
        if !fs::symlink_metadata(directory).is_ok_and(|metadata| metadata.file_type().is_dir()) {
            return Err(
                "Liquid is not installed. Choose Install Liquid to prepare its bundled model."
                    .into(),
            );
        }
    }
    Ok(())
}
fn install_from(source: &Path, config: &Config) -> Result<(), String> {
    let _lock = setup_lock(&config.directory)?;
    let packaged = read_manifest(source).map_err(|e| {
        format!(
            "Liquid setup found an invalid bundled model: {e}. Reinstall the complete app package."
        )
    })?;
    let root = config.model_directory();
    for directory in [config.directory.join("onnx"), root.clone()] {
        match fs::create_dir(&directory) {
            Ok(()) => {}
            Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => {}
            Err(error) => {
                return Err(format!(
                    "Liquid setup cannot create its model folder: {error}"
                ));
            }
        }
        if !fs::symlink_metadata(&directory).is_ok_and(|metadata| metadata.file_type().is_dir()) {
            return Err("Liquid setup model folder must be a regular directory.".into());
        }
    }
    for file in &packaged.files {
        let target = root.join(&file.name);
        if verify_file(&target, file.bytes, &file.sha256).is_ok() {
            continue;
        }
        let archive = source.join(file.archive_name());
        verify_file(&archive, file.compressed_bytes, &file.compressed_sha256).map_err(|_| {
            "Liquid setup found a damaged bundled model. Reinstall the complete app package."
                .to_owned()
        })?;
        let input = fs::File::open(archive)
            .map_err(|e| format!("Liquid setup cannot read its bundled model: {e}"))?;
        let mut output = tempfile::NamedTempFile::new_in(&root)
            .map_err(|e| format!("Liquid setup cannot prepare its model: {e}"))?;
        codec::decode_bounded(
            input,
            file.bytes,
            &file.sha256,
            &mut output,
            manifest::MAX_FILE_BYTES,
        )
        .map_err(|e| format!("Liquid setup cannot unpack its model: {e}"))?;
        output
            .as_file()
            .sync_all()
            .map_err(|e| format!("Liquid setup cannot save its model: {e}"))?;
        output
            .persist(target)
            .map_err(|e| format!("Liquid setup cannot publish its model: {e}"))?;
    }
    let mut output = tempfile::NamedTempFile::new_in(&root)
        .map_err(|e| format!("Liquid setup cannot prepare its manifest: {e}"))?;
    serde_json::to_writer(&mut output, &packaged)
        .map_err(|e| format!("Liquid setup cannot save its manifest: {e}"))?;
    output
        .flush()
        .map_err(|e| format!("Liquid setup cannot save its manifest: {e}"))?;
    output
        .persist(root.join(manifest::MANIFEST_NAME))
        .map_err(|e| format!("Liquid setup cannot publish its manifest: {e}"))?;
    Ok(())
}
/// Explicitly unlock before dropping the descriptor. Another thread can fork a
/// sidecar between acquiring this lock and dropping it; that child temporarily
/// inherits the open file description until exec. Relying only on descriptor
/// closure leaves a spurious live lock in that child after setup has finished.
#[derive(Debug)]
struct SetupLock {
    file: fs::File,
}
impl Drop for SetupLock {
    fn drop(&mut self) {
        let _ = self.file.unlock();
    }
}
/// Keep the lock inode: unlinking it lets another process lock a new inode while
/// an existing installer is still writing. Lock acquisition never blocks the UI.
fn setup_lock(directory: &Path) -> Result<SetupLock, String> {
    fs::create_dir_all(directory)
        .map_err(|error| format!("Cannot create Liquid's setup folder: {error}"))?;
    let file = fs::OpenOptions::new()
        .read(true)
        .write(true)
        .create(true)
        .truncate(false)
        .open(directory.join(".setup.lock"))
        .map_err(|error| format!("Cannot open Liquid's setup lock: {error}"))?;
    file.try_lock().map_err(|error| match error {
        fs::TryLockError::WouldBlock => "Liquid setup is already running in this folder. Choose Install Liquid to retry after it finishes.".to_owned(),
        fs::TryLockError::Error(error) => format!("Cannot lock Liquid's setup folder: {error}"),
    })?;
    Ok(SetupLock { file })
}

#[cfg(test)]
mod tests {
    use super::*;
    fn config(directory: &Path) -> Config {
        Config {
            directory: directory.into(),
            threads: 4,
        }
    }
    fn fixture(directory: &Path) -> manifest::Manifest {
        fs::create_dir_all(directory).unwrap();
        let files = [manifest::MODEL_NAME, manifest::TOKENIZER_NAME]
            .into_iter()
            .map(|name| {
                let bytes = format!("A small fixture for {name}").into_bytes();
                let archive = codec::encode_fixture(&bytes);
                let file = manifest::Asset {
                    name: name.into(),
                    bytes: bytes.len() as u64,
                    sha256: format!("{:x}", Sha256::digest(&bytes)),
                    compressed_bytes: archive.len() as u64,
                    compressed_sha256: format!("{:x}", Sha256::digest(&archive)),
                };
                fs::write(directory.join(file.archive_name()), archive).unwrap();
                file
            })
            .collect();
        let value = manifest::Manifest {
            format: manifest::FORMAT,
            model_id: manifest::MODEL_ID.into(),
            upstream_revision: manifest::UPSTREAM_REVISION.into(),
            files,
        };
        fs::write(
            directory.join(manifest::MANIFEST_NAME),
            serde_json::to_vec(&value).unwrap(),
        )
        .unwrap();
        value
    }
    #[test]
    fn configuration_and_shared_handle_do_no_eager_work() {
        let root = tempfile::tempdir().unwrap();
        let config = config(&root.path().join("never-created"));
        let _client = Client::default();
        assert!(!config.directory.exists());
        assert!(Arc::ptr_eq(&shared_client(), &shared_client()));
        assert!(validate_settings("", 4).is_ok());
        assert!(validate_settings(root.path().to_str().unwrap(), 1).is_ok());
        for (folder, threads) in [("relative", 4), ("/new\nfolder", 4), ("", 0), ("", 9)] {
            assert!(validate_settings(folder, threads).is_err());
        }
        assert!(
            Config::from_settings(&crate::settings::AppSettings::default())
                .unwrap()
                .directory
                .is_absolute()
        );
    }
    #[test]
    fn invalid_requests_fail_before_any_model_or_filesystem_work() {
        let root = tempfile::tempdir().unwrap();
        let config = config(&root.path().join("absent"));
        let mut client = Client::default();
        for texts in [
            vec![],
            vec![String::new(); 65],
            vec!["x".repeat(4097)],
            vec!["x".repeat(3000); 6],
        ] {
            assert!(client.correct(&config, &texts).is_err());
            assert!(!config.directory.exists());
        }
    }
    #[test]
    fn native_install_expands_verified_assets_offline_and_reuses_existing_files() {
        let source = tempfile::tempdir().unwrap();
        let manifest = fixture(source.path());
        let cache = tempfile::tempdir().unwrap();
        let config = config(cache.path());
        install_from(source.path(), &config).unwrap();
        let root = config.model_directory();
        for file in &manifest.files {
            verify_file(&root.join(&file.name), file.bytes, &file.sha256).unwrap();
        }
        let modified = fs::metadata(root.join(manifest::MODEL_NAME))
            .unwrap()
            .modified()
            .unwrap();
        // A ready cache needs neither payload archive, Python nor network.
        for file in &manifest.files {
            fs::remove_file(source.path().join(file.archive_name())).unwrap();
        }
        install_from(source.path(), &config).unwrap();
        assert_eq!(
            fs::metadata(root.join(manifest::MODEL_NAME))
                .unwrap()
                .modified()
                .unwrap(),
            modified
        );
    }
    #[test]
    fn install_does_not_publish_a_corrupt_or_incomplete_model() {
        let source = tempfile::tempdir().unwrap();
        let manifest = fixture(source.path());
        let cache = tempfile::tempdir().unwrap();
        let config = config(cache.path());
        fs::write(
            source.path().join(manifest.files[0].archive_name()),
            b"broken",
        )
        .unwrap();
        let error = install_from(source.path(), &config).unwrap_err();
        assert!(error.contains("damaged"));
        assert!(
            !config
                .model_directory()
                .join(manifest::MANIFEST_NAME)
                .exists()
        );
        assert!(!config.model_directory().join(manifest::MODEL_NAME).exists());
    }
    #[test]
    fn invalid_bundled_manifest_requires_repairing_the_app_package() {
        let source = tempfile::tempdir().unwrap();
        fs::write(source.path().join(manifest::MANIFEST_NAME), b"{}").unwrap();
        let cache = tempfile::tempdir().unwrap();
        let error = install_from(source.path(), &config(cache.path())).unwrap_err();
        assert!(
            error.contains("Reinstall the complete app package"),
            "{error}"
        );
        assert!(!error.contains("Install Liquid"));
    }
    #[cfg(unix)]
    #[test]
    fn install_rejects_redirected_cache_directories_before_writing_assets() {
        let source = tempfile::tempdir().unwrap();
        fixture(source.path());
        let cache = tempfile::tempdir().unwrap();
        let outside = tempfile::tempdir().unwrap();
        std::os::unix::fs::symlink(outside.path(), cache.path().join("onnx")).unwrap();
        let config = config(cache.path());
        assert!(
            install_from(source.path(), &config)
                .unwrap_err()
                .contains("regular directory")
        );
        assert!(!outside.path().join(manifest::MODEL_ID).exists());
        assert!(verify_model_directories(&config).is_err());
    }
    #[test]
    fn setup_lock_rejects_another_installer_and_keeps_the_inode() {
        let root = tempfile::tempdir().unwrap();
        let path = root.path().join(".setup.lock");
        fs::write(&path, b"existing lock").unwrap();
        let first = setup_lock(root.path()).unwrap();
        assert!(
            setup_lock(root.path())
                .unwrap_err()
                .contains("already running")
        );
        drop(first);
        drop(setup_lock(root.path()).unwrap());
        assert_eq!(fs::read(path).unwrap(), b"existing lock");
    }
    #[test]
    fn setup_lock_releases_even_when_a_child_inherits_its_descriptor() {
        let root = tempfile::tempdir().unwrap();
        let first = setup_lock(root.path()).unwrap();
        // A duplicated descriptor has the same lock lifetime as a descriptor
        // inherited across fork. Keep it alive to model a concurrent spawn.
        let inherited = first.file.try_clone().unwrap();
        drop(first);
        let next = setup_lock(root.path()).unwrap();
        assert!(setup_lock(root.path()).is_err());
        drop(inherited);
        assert!(
            setup_lock(root.path()).is_err(),
            "the next owner must remain locked"
        );
        drop(next);
        drop(setup_lock(root.path()).unwrap());
    }
    #[test]
    fn installed_integrity_rejects_same_size_changes_and_symlinks() {
        let root = tempfile::tempdir().unwrap();
        let path = root.path().join("asset");
        fs::write(&path, b"correct").unwrap();
        let hash = format!("{:x}", Sha256::digest(b"correct"));
        verify_file(&path, 7, &hash).unwrap();
        fs::write(&path, b"changed").unwrap();
        assert!(verify_file(&path, 7, &hash).is_err());
        #[cfg(unix)]
        {
            fs::remove_file(&path).unwrap();
            std::os::unix::fs::symlink(root.path(), &path).unwrap();
            assert!(verify_file(&path, 7, &hash).is_err());
        }
    }
}
