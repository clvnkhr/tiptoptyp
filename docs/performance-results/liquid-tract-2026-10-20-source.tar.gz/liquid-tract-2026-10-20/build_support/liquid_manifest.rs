//! Portable Liquid model payload contract shared by the app and package builder.
#![allow(dead_code)] // Runtime and packaging use different parts of the contract.
use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;

pub const FORMAT: u32 = 1;
pub const MODEL_ID: &str = "lfm25-encoder-350m-onnx18-v1";
pub const UPSTREAM_REVISION: &str = "4e2f724c10985e9ec90f34189c22be5d5f2e41e0";
pub const MANIFEST_NAME: &str = "manifest.json";
pub const MODEL_NAME: &str = "liquid.onnx";
pub const TOKENIZER_NAME: &str = "tokenizer.json";
pub const MAX_MANIFEST_BYTES: u64 = 64 * 1024;
pub const MAX_FILE_BYTES: u64 = 2 * 1024 * 1024 * 1024;
pub const MAX_TOTAL_BYTES: u64 = MAX_FILE_BYTES + 64 * 1024 * 1024;

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Manifest {
    pub format: u32,
    pub model_id: String,
    pub upstream_revision: String,
    pub files: Vec<Asset>,
}
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Asset {
    pub name: String,
    pub bytes: u64,
    pub sha256: String,
    pub compressed_bytes: u64,
    pub compressed_sha256: String,
}
impl Asset {
    pub fn archive_name(&self) -> String {
        format!("{}.zst", self.name)
    }
}
impl Manifest {
    pub fn parse(bytes: &[u8]) -> Result<Self, String> {
        if bytes.len() as u64 > MAX_MANIFEST_BYTES {
            return Err("Liquid manifest is too large".into());
        }
        let manifest: Self =
            serde_json::from_slice(bytes).map_err(|_| "Liquid manifest is invalid".to_owned())?;
        manifest.validate()?;
        Ok(manifest)
    }
    pub fn validate(&self) -> Result<(), String> {
        if self.format != FORMAT || self.model_id != MODEL_ID {
            return Err("Liquid model version is unsupported".into());
        }
        if self.upstream_revision != UPSTREAM_REVISION {
            return Err("Liquid model revision is invalid".into());
        }
        let mut names = BTreeSet::new();
        let mut total = 0u64;
        for file in &self.files {
            if !matches!(file.name.as_str(), MODEL_NAME | TOKENIZER_NAME)
                || !names.insert(file.name.as_str())
                || file.bytes == 0
                || file.bytes > MAX_FILE_BYTES
                || file.compressed_bytes == 0
                || file.compressed_bytes > MAX_FILE_BYTES
                || (file.name == TOKENIZER_NAME && file.bytes > 32 * 1024 * 1024)
                || [&file.sha256, &file.compressed_sha256].iter().any(|v| {
                    v.len() != 64
                        || !v
                            .bytes()
                            .all(|c| c.is_ascii_digit() || (b'a'..=b'f').contains(&c))
                })
            {
                return Err("Liquid model file entry is invalid".into());
            }
            total = total
                .checked_add(file.bytes)
                .ok_or("Liquid model is too large")?;
        }
        if names.len() != 2 || total > MAX_TOTAL_BYTES {
            return Err("Liquid model must contain its model and tokenizer".into());
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn manifest() -> Manifest {
        Manifest {
            format: FORMAT,
            model_id: MODEL_ID.into(),
            upstream_revision: UPSTREAM_REVISION.into(),
            files: [MODEL_NAME, TOKENIZER_NAME]
                .map(|name| Asset {
                    name: name.into(),
                    bytes: 8,
                    sha256: "b".repeat(64),
                    compressed_bytes: 4,
                    compressed_sha256: "c".repeat(64),
                })
                .into(),
        }
    }
    #[test]
    fn contract_requires_exact_model_tokenizer_and_bounded_safe_files() {
        assert!(manifest().validate().is_ok());
        for name in [
            "../liquid.onnx",
            "/liquid.onnx",
            "weights.bin",
            "tokenizer.json.zst",
        ] {
            let mut value = manifest();
            value.files[0].name = name.into();
            assert!(value.validate().is_err());
        }
        let mut value = manifest();
        value.files[0].bytes = MAX_FILE_BYTES + 1;
        assert!(value.validate().is_err());
        let mut value = manifest();
        value.files[0].sha256 = "g".repeat(64);
        assert!(value.validate().is_err());
        let mut value = manifest();
        value.files[0].sha256 = "B".repeat(64);
        assert!(value.validate().is_err());
        let mut value = manifest();
        value.files[0].compressed_sha256 = "C".repeat(64);
        assert!(value.validate().is_err());
        let mut value = manifest();
        value.files[0] = value.files[1].clone();
        assert!(value.validate().is_err());
        let mut value = manifest();
        value.model_id = "another-model".into();
        assert!(value.validate().is_err());
        assert!(Manifest::parse(&vec![b' '; MAX_MANIFEST_BYTES as usize + 1]).is_err());
    }
}
